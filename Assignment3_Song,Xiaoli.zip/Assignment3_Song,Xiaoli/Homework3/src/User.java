import java.text.*;
import java.util.*;
public class User implements java.io.Serializable  
{
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String Address;
    private String creditcard;
    
    static String confirmnum;
    static String order;
    static String delivery;
    static String cancle;

    
    
    
    public User()
    {
        firstName = "";
        lastName = "";
        emailAddress = ""; 
        Address = ""; 
        creditcard = ""; 
        confirmnum= "000000";
        order="00/00/00";
        delivery="00/00/00";
        cancle="00/00/00";
    
    }
    
    public User(String firstName, String lastName, String emailAddress, String Address, String creditcard,
    		String confirmnum,String order, String delivery, String cancle )
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.Address = Address;
        this.creditcard = creditcard;
        this.confirmnum= confirmnum;
        this.order = order;
        this.delivery = delivery;
        this.cancle = cancle;
      
       
    }
    
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getFirstName()
    { 
        return firstName; 
    }
    
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getLastName()
    { 
        return lastName; 
    }
    
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }

    public String getEmailAddress()
    { 
        return emailAddress; 
    }
    
    public void setAddress(String Address)
    {
        this.Address = Address;
    }

    public String getAddress()
    { 
        return Address; 
    }  
    
    public void setcreditcard(String creditcard)
    {
        this.creditcard = creditcard;
    }

    public String getcreditcard()
    { 
        return creditcard; 
    }
    
    
    
    public void setconfirmnum(String confirmnum)
    {
        this.confirmnum = confirmnum;
    }

    public String getconfirmnum()
    { 
        return confirmnum; 
    }
    
    
    public void setorder(String order)
    {
        this.order = order;
    }

    public String getorder()
    { 
        return order; 
    }
    
    
    public void setdelivery(String delivery)
    {
        this.delivery = delivery;
    }

    public String getdelivery()
    { 
        return delivery; 
    }
    
    
    public void setcancle(String cancle)
    {
        this.cancle = cancle;
    }

    public String getcancle()
    { 
        return cancle; 
    }
    

    
}
