


/** A catalog that lists the items available in inventory.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall; may be freely used or adapted.
 */

public class Catalog {
  // This would come from a database in real life.
  // We use a static table for ease of testing and deployment.
  // See JDBC chapters for info on using databases in
  // servlets and JSP pages.
  private static CatalogItem[] items =
    { new CatalogItem
      ("hall001",
       "Product name : Droid Maxx " ,
       "power for days , engineered to last for up to 48 hours on a single charge ",
       99.95),
      new CatalogItem
        ("hall002",
        	       "Product name : Moto X " ,
        	       "Moto X ",
        	       139.95),
      new CatalogItem
        ("hall003",
        	       "Product name : iPhone 5S " ,
        	       "iPhone 5S ",
        	       200.00),
   new CatalogItem
      ("hall004",
      "Product name : iPhone 5C " ,
        "iPhone 5C",
         178.35),
new CatalogItem
         ("hall005",
         "Product name : Galaxy S3 " ,
           "Galaxy S3 ",
            89.95),
 new CatalogItem
            ("hall006",
            "Product name : Galaxy S4 " ,
              "Galaxy S4 ",
               184.95),           
      new CatalogItem
        ("tablet001",
                "Product name : Kindle " ,
                "Kindle ",
                299.99),
new CatalogItem
                 ("tablet002",
                  "Product name : Nexus " ,
                 "Nexus",
                 189.55),
 new CatalogItem
                ("tablet003",
                 "Product name : Surface " ,
                 "Surface ",
                 245.10),
 new CatalogItem
                  ("tablet004",
                    "Product name : Galaxy " ,
                     "Galaxy ",
                     378.35),
      new CatalogItem
        ("tablet005",
                "Product name : iPad " ,
                "iPad ",
                289.95),
                
                
 new CatalogItem
                ("lap001",
                        "Product name : Macbook " ,
                        "Macbook ",
                        3099.99),
 new CatalogItem
              ("lap002",
              "Product name : Asus " ,
                "Asus ",
                3039.95), 
 new CatalogItem
          ("lap003",
          "Product name :Sony " ,
            "Sony ",
            3000.00),  
new CatalogItem
            ("lap004",
            "Product name :Leveno " ,
              "Leveno ",
              4078.35),             
 new CatalogItem
                 ("tv001",
                  "Product name :Panasonic" ,
                 "Panasonic ",
                 1099.99),     
                
 new CatalogItem
                ("tv002",
       "Product name : Samsung " ,
                  "Samsung ",
                  1230.00),
                        
 new CatalogItem
                ("tv003",
       "Product name : Sonytv " ,
                  "Sonytv ",
                  2000.00)                      
               
        };

  public static CatalogItem getItem(String itemID) {
    CatalogItem item;
    if (itemID == null) {
      return(null);
    }
    for(int i=0; i<items.length; i++) {
      item = items[i];
      if (itemID.equals(item.getItemID())) {
        return(item);
      }
    }
    return(null);
  }
}
               
