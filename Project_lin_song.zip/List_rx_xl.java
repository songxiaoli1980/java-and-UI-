

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class List_rx_xl <T>{

	final int MAX_SIZE =  100;		//max size of the array

	protected Object [] objArray;		//instance for object array
	private int index;		//next empty slot
	private int pointer;
	
	//default constructor
	public List_rx_xl() 
	{ 
		objArray = new Object[MAX_SIZE];
		index=0; //instantiates the array with the constant  
	}
	//nondefault constructor
	public List_rx_xl(int size)
	{
		objArray = new Object[size];
		index=0;
	}
	
	
	//instantiates the array with size
		
	//get length of an array
	public int getLength()
	{
		return objArray.length; //returns the length of the array
	}	
	@SuppressWarnings("unchecked")
	public T getArray()
	{//return a copy of the array
		Object [] array= new Object[objArray.length];
		for(int i=0; i<index;i++)
		{ 
			array[i]=objArray[i];
		}
		return (T)array;
	}
	
	public void setArray(Object [] anArray)
	{//assign anArray to this array
		
		objArray=anArray;
	}
	
	public int getIndex()
	{
		return index;
	}
	//returns the index
	
	public void setIndex(int anIndex)
	{//assigns a new value to the index
	index=anIndex;
	}
	
	public void setindex(int pos, Object obj)
	{
		objArray[pos]=obj; 
	}
	
	
	public Object getElement(int pos)
	{
		return (Object) objArray[pos];
	}
	//returns the element of the array at pos
	
	public void setElement(Object aLoc, int pos)
	{//assigns aLoc to array at pos
		objArray[pos]=aLoc;
	}
	public String toString()
	//iterates through the array and concatenates each element toString() into a string that is returned	
	{
		String a="";	//rename this to something else
		for(int i=0; i<index;i++)
		{
			a += objArray[i]+"\n";
		
		}
		return a;
	}
	
	
	
	public int sequentialSearch(Customer_rx_xl anCustomer) 
	//searches for and returns the index of anObj, -1 if not found
	{ 
		int counter=0;

		for (int i=0; i<getIndex(); i++)
		{
			counter++;
			//System.out.println("Array is "+objArray[i].toString());
			if(getElement(i).equals(anCustomer))
			{ 
				//System.out.println("sequtial found count is "+counter);
				System.out.println("find the reservation information is "+objArray[i].toString());
				return i;
			}
		}
		//System.out.println("sequtial not found count is "+counter);

		return -1;
	}
	
	
	//OVERLOAD METHOD
	public int sequentialSearch(String aName) 
	//searches for and returns the index of anObj, -1 if not found
	{ 
		int counter=0;
		Name_rx_xl a= new Name_rx_xl(aName);
		for (int i=0; i<getIndex(); i++)
		{
			counter++;
			//System.out.println("Array is "+objArray[i].toString());
			if(((Customer_rx_xl) getElement(i)).getName().equals(a))
			{ 
				//System.out.println("sequtial found count is "+counter);
				//System.out.println("your reservation information is "+objArray[i].toString());
				return i;
			}
		}
		//System.out.println("sequtial not found count is "+counter);

		return -1;
	}
	
	
	public int rSequentialSearch(Customer_rx_xl anCustom, int startingPos, int counter) {
		if(anCustom.equals(getElement(startingPos))) {
			System.out.println("rsequential search found count is "+(counter+1));
			return startingPos;
		}
		else if(startingPos < getIndex()-1) {
			return rSequentialSearch(anCustom, startingPos+1, counter+1);
		}
		System.out.println("rsequential search not found count is "+(counter+1));
		return -1;
	}

	public int rBinarySearch(Customer_rx_xl anCustom, int begin, int end, int counter) {
		int mid = (begin + end)/2;
		if(anCustom.equals(getElement(mid))){
			System.out.println("rbin search found count is "+(counter+1));
			return mid;
		}
		else if(begin > end) {
			System.out.println("rbin search  not found count is "+(counter+1));
			return -1;
		}
		else if(anCustom.compareTo(((Customer_rx_xl)getElement(mid))) > 0)
			return rBinarySearch(anCustom, mid+1, end, counter+1);
		else return rBinarySearch(anCustom, begin, mid-1, counter+1);
	}
	
	/*public void Sort()
	{  // Books nee= new Books();
	   int a=0;
		for(int i=0; i<getLength(); i++)

		{ a=i;
			//nee=(Books)objArray[i];
		for(int j=i+1;j<getLength(); j++)
		{if (((Books) objArray[j]).compareTo((Books)getElement(a))>0)
		{
			a=j;
		}}
		swap(i,a);

		}
	}*/
	

	public void Sort()
	{int counter=0;
	
	for(int i=0; i<getIndex()-1; i++)

	{ 
		 
		for(int j=i+1;j<getIndex(); j++)
		{counter++;
		if (((Comparable)getElement(i).toString()).compareTo(getElement(j).toString())>0)
			swap(i,j);
		}
		
	}
	System.out.println("sort count is "+counter);
	}
	
	
public void Sortdate()
	{int counter=0;
	for(int i=0; i<getIndex(); i++)

	{ 
		for(int j=i+1;j<getIndex(); j++)
		{counter++;
		if (((Customer_rx_xl)getElement(i)).getDate().compareTo(((Customer_rx_xl)getElement(j)).getDate())>0)
			{swap(i,j);}
		else if (((Customer_rx_xl)getElement(i)).getDate().compareTo(((Customer_rx_xl)getElement(j)).getDate())==0)
		{
			if (((Customer_rx_xl)getElement(i)).getTime().compareTo(((Customer_rx_xl)getElement(j)).getTime())>0)
			{swap(i,j);}	
		}
		}
	}
	//System.out.println("sort count is "+counter);
	}  
	
	

	public int binarySearch(Customer_rx_xl anCustom) 
	//searches for and returns the index of anObj, -1 if not found
	{  int counter=0;

	int start=0;
	int end=getIndex()-1;
	while(start<=end)
	{
		counter++;
		int mid= (start+end)/2;
		if(((Customer_rx_xl)objArray[mid]).compareTo(anCustom)==0)
		{
			System.out.println("binary search found count is "+counter);
			return mid;
		}
		else if (((Customer_rx_xl)objArray[mid]).compareTo(anCustom)<0)
		{  start=mid+1;
		}
		else
		{
			end=mid-1;
		}
	}
	System.out.println("binary search not found count is "+counter);
	return -1;
	}


	
	
	//store an element in the array
	public void add(Object aLoc)
	{
		objArray[index]=aLoc;
		index++;
	}
	
	// stores aStr in the  next empty slot in the array & increments the next empty slot variable
	
	public void delete(int pos)             //deletes the object at pos and moves all elements up
	{
		if (pos< index && pos>=0)
		{
			for (int i=pos; i<index; i++)
			{
				objArray[i]	=objArray[i+1];
			}
			index--;
		}
	}
	
	public void insert(int pos, Object anObj)		//inserts the object at pos and moves all elements down
	{
		for (int i=index; i>pos; i--)
		{
			objArray[i]	=objArray[i-1];
		}
		objArray[pos]=anObj;		//same as setElement(anObj,pos)
		index++;
	}      
	
	public int isThere(Object anObj) 
	//searches for and returns the index of anObj, -1 if not found
	{
	for (int i=0; i<index; i++)	
		if(objArray[i].equals(anObj))
		{
			return i;
		}
	/*	if(anObj instanceof Books){
			if(	((Books)(objArray[i])).equals(anObj)){
				return i;
			}

		}
		else{
			if(	((Books)(objArray[i])).equals(anObj)){
				return i;
			}

		}*/
			return -1;
	}

	public int delete(Object anObj)   //searches for anObj, returns the index of anObj, -1 if not found
    {
		int pos=-1;
		for (int i=0; i<index; i++)	
			{if(objArray[i].equals(anObj)) 
				pos=i;
				}
		if (pos<index && pos>=0)
		{
			for(int i=pos; i<index; i++)
			{objArray[i]=objArray[i+1];
			}
			index--;
		}
		return pos;
    }
	
	public boolean isFull()		//returns true if array is full, false if array is not
	{
		
			if(index==objArray.length)
			{ moreCapacity();
				return true;
			}
			
	 	return false;
	 	
	 	
		
	}
	
	public boolean isEmpty()		//returns true if array is empty, false if array is not
	{
		if(index==0)
		return true;
		else
		return false;
	}
	
	
	public void swap(int a , int b)			
	{Object obj;
		if(a<index && b<index)
		{obj= objArray[a];
		objArray[a]=objArray[b];
		objArray[b]=obj;
		}
	}
	
	public void clear()			//deletes all data from list
	{
		index=0;	//setIndex(0);
	}
	 
	public void trim()				//remove excess capacity so that capacity matches size
	{  Object [] objs= new Object[index];
		for (int i=0; i<index; i++)
			objs[i]=objArray[i];
		setArray(objs);
			
	}
	public void moreCapacity()		//automatically allocates more memory if needed
	{Object [] objs1= new Object[objArray.length+6];
	for (int i=0; i<index; i++)
		objs1[i]=objArray[i];
	setArray(objs1);
	}
	
	
	
	void reset()		//sets the iterator ��pointer�� to 0
	{
		pointer=0;
	}
	
	boolean hasNext()  //returns boolean if there is more data in the array
	{
	if (pointer<index)
		return true;
	else 
		return false;
	
	}
	T getNext()	//returns the object at the iterator ��pointer��, increments pointer
	
	{
		pointer++;
		return (T)objArray[pointer-1];
	}

	public void insert(Object in)
	{
		objArray[index]=in;
		index++;
	}
	
	
	public static int backwards2(int a)
	{
		if(a==0)
         return 0;
		else 
			return backwards2(a-2);
	}
	
	
	
	public void createfile(List_rx_xl search) {
		Scanner input = new Scanner(System.in);
		
		FileWriter fileOut = null;
	try {
		fileOut = new FileWriter("OutputFile_lin_song.txt");
	} catch (IOException e) {
		e.printStackTrace(); // show you where the error happened
	}
	BufferedWriter outFile = new BufferedWriter(fileOut);
	search.reset();
	while (search.hasNext()) {

		// System.out.println(money.getNext().toString());
		String bo = search.getNext().toString();
		//System.out.println("book is" + bo);
		try {
			outFile.write(bo + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	try {
		outFile.close();
	} catch (IOException e) {
		e.printStackTrace();
	}
	}

	
	
}


