	/*
	 * design class defination for name
	 * RuixiangLin_XiaoliSong
	 */
public class Name_rx_xl {
		String name;
		//default constructor
		public Name_rx_xl() {
			name = "";
		}
		//nondefault constructor
		public Name_rx_xl(String name1){
			name = name1;
		}
		//accessor
		public String getName(){
			return name;
		}
		//mutator
		public void setName(String name2){
			name = name2;
		}
		//toString
		public String toString(){
			return name;
		}
		//equals() method
		public boolean equals(Name_rx_xl name1) {
			
			if(name.equals(name1.getName()))
				return true;
			return false;
		}
		//compareTo() method
		public int compareTo(Name_rx_xl aName)
		{
			if (name.compareTo(aName.getName())<0)
					return -1;
			else if (name.compareTo(aName.getName())>0)
				return 1;
			else
				return 0 ;
			
		}
	}
