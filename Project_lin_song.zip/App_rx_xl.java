import java.io.BufferedWriter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*this program for the restaurant reservation, the custom can search their reservation , make reservation, delete their reservation, modify their reservation and check in.
 the restaurant people also can sort the reservation.
  the customer can use their name(First Middle Last) to search their reservation ;
  the customer can make the reservation by input their name(First Middle Last), the date of their reservation, the time, the number of people
  the customer can delete their reservation by input their name(First Middle Last),
  the customer can modify their reservation,
  the customer can check in by input their email,
  the customer can seat the reservation.

  
 CheckInCustomer_rx_xl class is the child class of the parents class Customer_rx_xl , 
  the Customer_rx_xl defied the reservation information of customer name, it has the customer name, the reservation date, the time, the number of people, 
  the CheckInCustomer_rx_xl class has the customer name, the reservation date, the time, the number of people, and if check in , will input the email to check in, 
  the List_rx_xl is the Array list and the method
  Name_rx_xl is the Name class, which has-a relation with Customer_rx_xl class */

public class App_rx_xl {
	
	public static boolean isbigerto200(double time2,List_rx_xl mList,int insertpeople)
	{  int Number=0;
		for(int i=0;i<mList.getLength();i++)
		{ if(null!=mList.getElement(i))
			if (time2-1<((Customer_rx_xl)mList.getElement(i)).getTime2()&&((Customer_rx_xl)mList.getElement(i)).getTime2()<=time2)
			Number=Number+((Customer_rx_xl)mList.getElement(i)).getNum();
		}
		if (Number>200||( Number+insertpeople)>200)
		{return true;}
		return false;	
		}
	
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Scanner input1 = new Scanner(System.in);
		List_rx_xl searchList = new List_rx_xl();

		// readfile
		String line = ""; // initalize variable to store line read from file
		String[] token;


		try {
			Scanner inFile = new Scanner(new FileReader(
					"InputFile_lin_song.txt"));
			while (inFile.hasNext()) {
				line = inFile.nextLine(); // read line from file and store
				token = line.split(",");

				if (token.length == 5) {
					int a = Integer.parseInt(token[3].trim());
					Name_rx_xl aName = new Name_rx_xl();
					aName.setName(token[0]);
					CheckInCustomer_rx_xl obj = new CheckInCustomer_rx_xl(
							aName, token[1], token[2], a, token[4]);
					searchList.add(obj);

				} else if (token.length == 4) {
					int a = Integer.parseInt(token[3].trim());
					Name_rx_xl aName = new Name_rx_xl();
					aName.setName(token[0]);
					Customer_rx_xl obj = new Customer_rx_xl(aName, token[1],
							token[2], a);
					searchList.add(obj);

				}
			}
			inFile.close(); // close the file

		} catch (FileNotFoundException fnfe) {
			System.out.println("not found file");
		}

		for (int i = 0; i < searchList.getIndex(); i++) {
			System.out.println(searchList.getElement(i).toString());
		}

		// menu()
		System.out
				.println("1.Confirm reservation,please input your name(First Middle Last)");
		System.out
				.println("2.Make reservation,please add First name Middle name Last name,reservation date, reservation time, number of people");
		System.out.println("3.Delete reservation");
		System.out.println("4.Modify reservation");
		System.out
				.println("5.Seat reservation (you can check the seat and change the number of people)");
		System.out
				.println("6.check in, please input your email, the form is xxxx@xxxx.com ");
		System.out.println("7. show the reservation");
		System.out.println("8. sort reservation");
		System.out.println("9. output a file");
		System.out.println("if input -1, that means exit");

		int numberCustomers = 0;
		int flag = 10;
		final int sentinel = -1;
		while (flag != sentinel) {// while loop to create menu
			System.out.println("please input the number of menu");
			flag = input.nextInt();
			if (flag == 1) {
				System.out
						.println("if you want to Confirm reservation,please input your name(First,Middle,Last)");

				Name_rx_xl aName = new Name_rx_xl();

				String Nam = input1.nextLine();
				aName.setName(Nam);
				int pos = searchList.sequentialSearch(Nam);
				System.out.println("the position is" + pos);
				if (pos == -1) {
					System.out
							.println("Didn't find your reservation , didn't confirmed, please check your input");
				} else if (pos != -1) {
					System.out.println("your reservation is confirmed");
				}
			}

			else if (flag == 2) {
				System.out
						.println(" Make reservation,please add First name Middle name Last name,reservation date, reservation time, number of people");
				System.out
						.println(" Note: the reservation time from 11:00 to 21:00");
				String add = input1.nextLine();
				token = add.split(",");
				Customer_rx_xl temp = null;
				int a = Integer.parseInt(token[3].trim());
				Name_rx_xl bName = new Name_rx_xl();
				bName.setName(token[0]);
				Customer_rx_xl obj = new Customer_rx_xl(bName, token[1],
						token[2], a);
				
		
				double newtime = obj.getTime2();
				if(isbigerto200(newtime,searchList,obj.getNum()))
				{
					System.out
					.println("too much people, please delay your reservation time ");
					
				}
				

				else 
				{
				if (token[2].compareTo("11:00") >= 0
						&& token[2].compareTo("21:00") <= 0) {
					
							searchList.add(obj);

							System.out.println("the reservation is "
									+ obj.toString());
							temp = obj;
						} 
				else {
					System.out
							.println("the time is not the reservation time,please make reservation at the right time ");
				}
				
					} 

				}

			

		

			else if (flag == 3) {

				System.out
						.println("input Firstname Middlename Lastname if you want to delete reservation");
				Name_rx_xl aName = new Name_rx_xl();
				String Nam = input1.nextLine();
				aName.setName(Nam);

				int pos = searchList.sequentialSearch(Nam);
				searchList.delete(pos);
				System.out.println("your reservation is deleted");
			}

			else if (flag == 4) {
				System.out
						.println("Modify your reservation, input Firstname Middlename Lastname");
				Name_rx_xl aName = new Name_rx_xl();
				String Nam = input1.nextLine();
				aName.setName(Nam);

				int pos = searchList.sequentialSearch(Nam);
				Customer_rx_xl b1 = new Customer_rx_xl();
				b1 = (Customer_rx_xl) searchList.getElement(pos);
				System.out.println("the position is" + b1);
				
				System.out.println(" please input your update(date,time,number of people) ");
				Scanner input3=new Scanner(System.in);
				String info = input3.nextLine();
				String [] infoArr= info.split(",");
				((Customer_rx_xl) searchList.getElement(pos)).setDate(infoArr[0]);
				((Customer_rx_xl) searchList.getElement(pos)).setTime(infoArr[1]);
				((Customer_rx_xl) searchList.getElement(pos)).setNum(Integer.parseInt(infoArr[2]));
				
//				searchList.delete(pos);
//				System.out
//						.println(" please input the menu number 2 to input your new reservation");

			}

			else if (flag == 5) {
				System.out
						.println("seat the reservation, only change the number of people, input the firstname middlename lastname to find your reservation");
				Name_rx_xl aName = new Name_rx_xl();
				String Nam = input1.nextLine();
				aName.setName(Nam);

				int pos = searchList.sequentialSearch(Nam);
				Customer_rx_xl b1 = new Customer_rx_xl();
				b1 = (Customer_rx_xl) searchList.getElement(pos);
				System.out.println("the position is" + b1
						+ " /n  input the number of people");
				int a = input1.nextInt();
				b1.setNum(a);
				System.out
						.println("the number of people become " + b1.getNum());
			}

			else if (flag == 6) {
				System.out
						.println("check in, the check in customer must input their name(First Middle Last) to check in");
				Name_rx_xl aName = new Name_rx_xl();
				String Nam = input1.nextLine();
				aName.setName(Nam);

				int pos = searchList.sequentialSearch(Nam);
				Customer_rx_xl b1 = new Customer_rx_xl();
				if (pos!=-1)
				{b1 = (Customer_rx_xl) searchList.getElement(pos);
				System.out.println("the position is" + b1);}
				
				System.out.println(" if you are the reservers,please input your email(XXX@rer.com) , and you can get 80% coupon");
				System.out.println(" if you are the new people,please input your name(First Middle Last),email(XXX@rer.com) , you can get 80% coupoun for the next time");
				CheckInCustomer_rx_xl newcustomer=null;
				
				if (pos!=-1)
				{Scanner input3=new Scanner(System.in);
				String info = input3.nextLine();
				newcustomer=new CheckInCustomer_rx_xl(((Customer_rx_xl) searchList.getElement(pos)).getName(),
						((Customer_rx_xl) searchList.getElement(pos)).getDate(),
						((Customer_rx_xl) searchList.getElement(pos)).getTime(),
						((Customer_rx_xl) searchList.getElement(pos)).getNum(),info
						);
				searchList.setindex(pos, newcustomer);
//				Object obj = searchList.getElement(pos);
//				obj =(Customer_rx_xl)newcustomer;
//				
				}
				
				
				else 
				{Scanner input3=new Scanner(System.in);
				String info = input3.nextLine();
				String [] infoArr= info.split(",");
				Name_rx_xl nam = new Name_rx_xl();
				
				nam.setName(infoArr[0]);

				newcustomer=new CheckInCustomer_rx_xl(nam,"00000000","00:00",0,infoArr[1]);
				
				searchList.add(newcustomer);
				}
				
				
				System.out.println("input the menu number 7 to see the rusult" );
			}
			

			else if (flag == 7) {
				for (int i = 0; i < searchList.getIndex(); i++) {
					System.out.println(searchList.getElement(i).toString());
				}
			}

			else if (flag == 8) {
				searchList.Sortdate();
			}

			else if (flag == 9) {
				searchList.createfile(searchList);
				System.out.println();
				System.out.println("Your file was successfully created");
			}

		}

		System.out.println("Program closed.");

	}

}
