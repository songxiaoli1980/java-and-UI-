public class Customer_rx_xl {
	Name_rx_xl aName;
	String date;
	String time;
	double time2;
	int num;
	String[]timeArr;
	//default constructor
	public Customer_rx_xl(){
	    Name_rx_xl aName = new Name_rx_xl();
		date = "20120901";
		time = "15:00";
		num = 5;
	}
	//nonfault construcotr
	public Customer_rx_xl(Name_rx_xl bName, String date1, String time1, int num1)
	{
		aName = bName;
		date = date1;
		time = time1;
		num = num1;
	}
	//accessor
	public Name_rx_xl getName(){
		return aName;
	}
	public String getDate(){
		return date;
	}
	public String getTime(){
		return time;
	}
	public int getNum(){
		return num;
	}
	
	public double getTime2()
	{if (time2==0)
	{		timeArr = time.split(":");
	
	time2 = Integer.parseInt(timeArr[0])
			+ Integer.parseInt(timeArr[1]) / 60.0;
	}
	return time2;
	}
	
	//mutator
	public void setName(Name_rx_xl name2){
		aName = name2;
	}
	public void setDate(String date2){
		date = date2;
	}
	public void setTime(String time2){
		time = time2;
	}
	public void setNum(int num2){
		num = num2;
	}
	//toString()
	public String toString(){
		return( aName.toString() +"," + date +"," + time + "," + num);
	}
	//compareTo
			public int compareTo(Customer_rx_xl aCustomer) {
				if(Integer.parseInt(date)>Integer.parseInt(aCustomer.getDate()))	
				return 1;
				else if	(Integer.parseInt(date)<Integer.parseInt(aCustomer.getDate()))	
				return -1;
				else
					return 0;
			}
			
			//equals method
				public boolean equals(Customer_rx_xl aCustomer) 
				{
					if(date.equals(aCustomer.getDate()))
						return true;
					else
						return false;
				}	
}
