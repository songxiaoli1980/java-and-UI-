public class CheckInCustomer_rx_xl extends Customer_rx_xl{
	String email;
	//default constructor
	public CheckInCustomer_rx_xl(){
		super();
		email = "";
	}
	//nondefault constructor
	public CheckInCustomer_rx_xl(String email1){
		super();
		email = email1;
	}
	public CheckInCustomer_rx_xl(Name_rx_xl name1, String date1, String time1, int num1, String email1){
		super(name1, date1, time1, num1);
		email = email1;
	}
	//accessor
	public String getEmail(){
		return email;
	}
	//mutator
	public void setEmail(String email2){
		email = email2;
	}
	//toString
	public String toString()
	{
		return super.toString()+ ","+email;
	}
	//compareTO() method
	public int compareTo(CheckInCustomer_rx_xl CheckCustomer){
		if(email.compareTo(CheckCustomer.getEmail())>0)
			return 1;
		else if(email.compareTo(CheckCustomer.getEmail())<0)
			return -1;
		else
			return 0;
	}
	// overload method
	public int compareTo(CheckInCustomer_rx_xl CheckCustomer1,CheckInCustomer_rx_xl CheckCustomer2){
		if(CheckCustomer1.getEmail().compareTo(CheckCustomer2.getEmail())>0)
			return 1;
		else if(CheckCustomer1.getEmail().compareTo(CheckCustomer2.getEmail())<0)
			return -1;
		else
			return 0;
	}
	
}
